




public class karywan {
	        private String kode;
	        String nama;
	        String kelamin;
	        String jabatan;
	        Integer gaji;
		public karywan(String kode,
		String nama,
		String kelamin,
		String jabatan,
		Integer gaji) {
			this.kode = kode;
			this.nama = nama;
			this.kelamin = kelamin;
			this.jabatan = jabatan;
			this.gaji = gaji;
		}

		
		public String getkode() {
		return kode;   
		}

		public String getnama() {
			return nama;   
			}
		public String getkelamin() {
				return kelamin;   
			}
		public String getjabatan() {
				return jabatan;   
			}
		public Integer getgaji() {
				return gaji;   
			}
		
		public void setnama(String nama) {
			this.nama = nama;
		}
		public void setkelamin(String kelamin) {
			this.kelamin = kelamin;
		}
		public void setjabatan(String jabatan) {
			this.jabatan = jabatan;
		}
		public void setkode(String kode) {
			this.kode = kode;
		}
		public void setgaji(Integer gaji) {
			this.gaji = gaji;
		}
	    
		
		public static void main(String[] args) {
			

		}

	}