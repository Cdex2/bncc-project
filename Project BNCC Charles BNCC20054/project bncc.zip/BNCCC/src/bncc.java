import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public class bncc {

	public bncc() {
		Scanner scan = new Scanner(System.in);
		Random rand = new Random();
		ArrayList<String> arraykaryawan = new ArrayList<>();
		ArrayList<String> arraykode = new ArrayList<>();
		ArrayList<String> arraynama = new ArrayList<>();
		ArrayList<String> arrayjabatan = new ArrayList<>();
		ArrayList<Integer> arraygaji = new ArrayList<>();
		ArrayList<String> arraykelamin = new ArrayList<>();
		int menu = 0;
		String Manager = "Manager";
		String Supervisor = "Supervisor";
		String Admin = "Admin";
		
		String kode;
		String nama;
		String kelamin;
		String jabatan;
		Integer gaji;
		
		
		    
			
			

			

		

		
		{
			
				
		   do {
			
		
			System.out.println("1.insert data karyawan ");
			System.out.println("2.view data karyawan");
			System.out.println("3.update data karyawan");
			System.out.println("4.delete data karyawan");
			System.out.println("0.exit");
			System.out.println("choose: ");
			menu = scan.nextInt();scan.nextLine();
			 {
				
			}
				
			
		    switch (menu) {
			case 1:
				Character a;
				Character b;
				Integer c,d,e,f;
				
				a = (char)(rand.nextInt(26) + 'A');
				b = (char)(rand.nextInt(26) + 'A');
				c = rand.nextInt(10);
				d = rand.nextInt(10);
				e = rand.nextInt(10);
				f = rand.nextInt(10);
				
				kode = (a.toString() + b.toString() + '-' + c.toString() + d.toString() + e.toString() + f.toString());
				System.out.println("kode karyawan anda adalah : " + kode);
				
				do {
					System.out.println("masukan nama: ");
					nama = scan.nextLine();
				} while (nama.length() < 3);
				
				do {
					System.out.println("masukan kelamin: pria atau perempuan");
					kelamin = scan.nextLine();
				} while (!kelamin.equalsIgnoreCase("Pria") && (!kelamin.equalsIgnoreCase("Perempuan")));
				
				do {
					System.out.println("masukan jabatan: Manager, Supervisor, Admin ");
					jabatan = scan.nextLine();
					if (jabatan.equals(Manager)) {
						gaji = 8000000;
					}
					if (jabatan.equals(Supervisor)) {
						gaji = 6000000;
					}
					
					else {
						gaji = 4000000;
					}
				} while (!jabatan.equalsIgnoreCase("Manager") && (!jabatan.equalsIgnoreCase("Supervisor") && (!jabatan.equalsIgnoreCase("Admin"))));
				
				
				
				
				arraykode.add(kode);
				arraynama.add(nama);
				arraykelamin.add(kelamin);
				arrayjabatan.add(jabatan);
				arraygaji.add(gaji);
				arraykaryawan.add(kode + "" + nama  + "" + kelamin + "" +jabatan + "" + gaji) ;
				
				System.out.println(arraykaryawan);
				menu = scan.nextInt();scan.nextLine();
				
				
				
				break;
               
			case 2:
				for (int x = 0; x < arraykaryawan.size(); x++) {
					System.out.println(arraykode.get(x));
					System.out.println(arraynama.get(x));
					System.out.println(arraykelamin.get(x));
					System.out.println(arrayjabatan.get(x));
					System.out.println(arraygaji.get(x));
				}
				break;
				
			case 3:
				int no = 0;
				for (int x = 0; x < arraykaryawan.size(); x++) {
					System.out.println(arraykode.get(x));
					System.out.println(arraynama.get(x));
					System.out.println(arraykelamin.get(x));
					System.out.println(arrayjabatan.get(x));
					System.out.println(arraygaji.get(x));
					
				}
				no = scan.nextInt();scan.nextLine();
				a = (char)(rand.nextInt(26) + 'A');
				b = (char)(rand.nextInt(26) + 'A');
				c = rand.nextInt(10);
				d = rand.nextInt(10);
				e = rand.nextInt(10);
				f = rand.nextInt(10);
				arraykaryawan.get(no - 1);
				System.out.println("set new data");
				kode = (a.toString() + b.toString() + '-' + c.toString() + d.toString() + e.toString() + f.toString());
				System.out.println("kode karyawan anda adalah : " + kode);
				
				do {
					System.out.println("masukan nama: ");
					nama = scan.nextLine();
				} while (nama.length() < 3);
				
				do {
					System.out.println("masukan kelamin: pria atau perempuan");
					kelamin = scan.nextLine();
				} while (!kelamin.equalsIgnoreCase("Pria") && (!kelamin.equalsIgnoreCase("Perempuan")));
				
				do {
					System.out.println("masukan jabatan: Manager, Supervisor, Admin ");
					jabatan = scan.nextLine();
					if (jabatan.equals(Manager)) {
						gaji = 8000000;
					}
					if (jabatan.equals(Supervisor)) {
						gaji = 6000000;
					}
					
					else {
						gaji = 4000000;
					}
				} while (!jabatan.equalsIgnoreCase("Manager") && (!jabatan.equalsIgnoreCase("Supervisor") && (!jabatan.equalsIgnoreCase("Admin"))));
				
				
				
				
				
				arraykode.add(kode);
				arraynama.add(nama);
				arraykelamin.add(kelamin);
				arrayjabatan.add(jabatan);
				arraygaji.add(gaji);
				arraykaryawan.add(kode + "" + nama  + "" + kelamin + "" +jabatan + "" + gaji) ;
				
				System.out.println(arraykaryawan);
				menu = scan.nextInt();scan.nextLine();
				break;
			
			
			
			case 4:
				Integer delete = 0;
				for (int x = 0; x < arraykaryawan.size(); x++) {
					System.out.println(arraykode.get(x));
					System.out.println(arraynama.get(x));
					System.out.println(arraykelamin.get(x));
					System.out.println(arrayjabatan.get(x));
					System.out.println(arraygaji.get(x));
					do {
						System.out.println("input to be delete [ 1 - 4 ]");
						delete = scan.nextInt();
						delete -= 1;
					} while (delete < 0 || delete >= arraykaryawan.size());
					arraykode.remove(x);
					arraynama.remove(x);
					arraykelamin.remove(x);
					arrayjabatan.remove(x);
					arraygaji.remove(x);
					arraykaryawan.remove(x);
				}
			default:
				break;
			}

		   } while (menu != 0);}
	
}


	public static void main(String[] args) {
	}}